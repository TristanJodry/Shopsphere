#!/bin/bash
set -e

DOMAIN=$1
EMAIL=$2

if [ -z "$DOMAIN" ] || [ -z "$EMAIL" ]; then
    echo "Usage: $0 <domain> <email>"
    echo "Example: $0 shopsphere.example.com admin@example.com"
    exit 1
fi

echo "🚀 Setting up HTTPS for $DOMAIN..."

# 1. Install Nginx and Certbot
echo "📦 Installing Nginx and Certbot..."
apt-get update
apt-get install -y nginx certbot python3-certbot-nginx

# 2. Update Node.js App to run on Port 3000
echo "⚙️  Reconfiguring ShopSphere service to run on port 3000..."
# We modify the existing service file to change PORT=80 to PORT=3000
sed -i 's/Environment=PORT=80/Environment=PORT=3000/' /etc/systemd/system/shopsphere.service
systemctl daemon-reload
systemctl restart shopsphere

# 3. Configure Nginx Proxy
echo "🔧 Configuring Nginx..."
cat > /etc/nginx/sites-available/shopsphere <<EOF
server {
    listen 80;
    server_name $DOMAIN;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
    }
}
EOF

# Enable site
ln -sf /etc/nginx/sites-available/shopsphere /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

# Test and Reload Nginx
nginx -t
systemctl reload nginx

# 4. Request SSL Certificate
echo "🔐 Setup Complete! Ready for HTTPS."
echo "   To enable HTTPS, run the following command manually:"
echo ""
echo "   sudo certbot --nginx -d $DOMAIN"
echo ""

# certbot --nginx --non-interactive --agree-tos --email $EMAIL -d $DOMAIN


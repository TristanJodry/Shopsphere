// Mobile Menu Toggle
const menuToggle = document.getElementById('menuToggle');
const nav = document.getElementById('nav');

if (menuToggle) {
    menuToggle.addEventListener('click', () => {
        nav.classList.toggle('active');
    });
}

// Header Scroll Effect
const header = document.getElementById('header');
let lastScroll = 0;

window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;

    if (currentScroll > 100) {
        header.classList.add('scrolled');
    } else {
        header.classList.remove('scrolled');
    }

    lastScroll = currentScroll;
});

// Load and animate stats
async function loadStats() {
    try {
        const response = await fetch('/api/stats');
        const stats = await response.json();

        // Update stat cards with real data
        const statCards = document.querySelectorAll('.stat-card');
        if (statCards.length >= 3) {
            statCards[0].querySelector('.stat-number').setAttribute('data-target', stats.customers);
            statCards[1].querySelector('.stat-number').setAttribute('data-target', stats.orders);
            statCards[2].querySelector('.stat-number').setAttribute('data-target', Math.floor(stats.revenue));
        }
    } catch (error) {
        console.error('Error loading stats:', error);
    }
}

// Animated Counter for Stats
function animateCounter(element, target, duration = 2000) {
    const start = 0;
    const increment = target / (duration / 16);
    let current = start;

    const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
            element.textContent = formatNumber(target);
            clearInterval(timer);
        } else {
            element.textContent = formatNumber(Math.floor(current));
        }
    }, 16);
}

function formatNumber(num) {
    if (num >= 1000000) {
        return '€' + (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
        return (num / 1000).toFixed(0) + 'K+';
    }
    return num.toString();
}

// Intersection Observer for Animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -100px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';

            // Animate counters when stats section is visible
            if (entry.target.classList.contains('stat-card')) {
                const numberElement = entry.target.querySelector('.stat-number');
                const target = parseInt(numberElement.getAttribute('data-target'));
                animateCounter(numberElement, target);
            }

            observer.unobserve(entry.target);
        }
    });
}, observerOptions);

// Observe all animated elements
document.querySelectorAll('.fade-in-up').forEach(el => {
    observer.observe(el);
});

// Load Products from API
async function loadProducts() {
    const productsGrid = document.getElementById('productsGrid');

    try {
        const response = await fetch('/api/products');
        const products = await response.json();

        // Clear loading message
        productsGrid.innerHTML = '';

        // Create product cards
        products.forEach((product, index) => {
            const card = createProductCard(product, index);
            productsGrid.appendChild(card);
        });

        // Observe new product cards for animation
        document.querySelectorAll('.product-card').forEach(el => {
            observer.observe(el);
        });

    } catch (error) {
        console.error('Error loading products:', error);
        productsGrid.innerHTML = '<div class="loading">Failed to load products. Please refresh the page.</div>';
    }
}

// Create Product Card HTML
function createProductCard(product, index) {
    const card = document.createElement('div');
    card.className = 'product-card fade-in-up';
    card.style.animationDelay = `${index * 0.1}s`;

    const badgeHTML = product.badge ? `<span class="product-badge">${product.badge}</span>` : '';

    // Determine image type
    const imageHTML = product.imageType === 'photo'
        ? `<img src="${product.image}" alt="${product.name}" style="width: 100%; height: 100%; object-fit: cover;">`
        : `<span class="material-icons" style="font-size: 6rem; color: white;">${product.image}</span>`;

    card.innerHTML = `
        <div class="product-image" style="background: ${product.gradient}">
            ${badgeHTML}
            ${imageHTML}
        </div>
        <div class="product-info">
            <div class="product-category">${product.category}</div>
            <h3 class="product-name">${product.name}</h3>
            <p class="product-description">${product.description}</p>
            <div class="product-footer">
                <div class="product-price">€${product.price.toFixed(2)}</div>
                <button class="btn" onclick="addToCart(${product.id})">Add to Cart</button>
            </div>
        </div>
    `;

    return card;
}

// Add to Cart (Mock Function)
function addToCart(productId) {
    // Animation feedback
    const btn = event.target;
    const originalText = btn.textContent;

    btn.textContent = 'Added!';
    btn.style.background = '#10b981';

    setTimeout(() => {
        btn.textContent = originalText;
        btn.style.background = '';
    }, 1500);

    console.log(`Product ${productId} added to cart`);
}

// Smooth Scroll for Navigation Links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));

        if (target) {
            const headerOffset = 80;
            const elementPosition = target.getBoundingClientRect().top;
            const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

            window.scrollTo({
                top: offsetPosition,
                behavior: 'smooth'
            });

            // Close mobile menu if open
            if (nav.classList.contains('active')) {
                nav.classList.remove('active');
            }
        }
    });
});

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    loadStats();
    loadProducts();
});

// Add some parallax effect to hero
window.addEventListener('scroll', () => {
    const scrolled = window.pageYOffset;
    const hero = document.querySelector('.hero-content');
    if (hero) {
        hero.style.transform = `translateY(${scrolled * 0.3}px)`;
        hero.style.opacity = 1 - (scrolled / 600);
    }
});

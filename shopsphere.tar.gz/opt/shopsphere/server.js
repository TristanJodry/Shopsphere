// Load environment variables from .env file (for local development)
require('dotenv').config();

const express = require('express');
const path = require('path');
const { Pool } = require('pg');
const fs = require('fs');


const app = express();
const PORT = process.env.PORT || 80;

// Development mode - no database required
const DEV_MODE = process.env.DEV_MODE === 'true';

// Read database IP from environment or file
let dbHost = null;
let pool = null;

if (DEV_MODE) {
    console.log('🚀 Running in DEV MODE - Using mock data (no database required)');
} else {
    // First, try environment variable (set by systemd)
    if (process.env.DB_HOST) {
        dbHost = process.env.DB_HOST;
        console.log(`✅ Database host loaded from environment: ${dbHost}`);
    }
    // Second, try reading from temp file (VM startup script)
    else if (fs.existsSync('/tmp/db-host.txt')) {
        dbHost = fs.readFileSync('/tmp/db-host.txt', 'utf8').trim();
        console.log(`⚠️  Database host loaded from temp file: ${dbHost}`);
    }

    // If still no DB host, exit with error
    if (!dbHost) {
        console.error('\n❌ FATAL ERROR: Database host not configured!');
        console.error('   Please ensure DB_HOST environment variable is set in systemd service.');
        console.error('   Run: ./quick-fix-db-host.sh <project-id> <zone>\n');
        process.exit(1);
    }


    // Validation: Ensure database credentials are present
    if (!process.env.DB_USER || !process.env.DB_PASSWORD) {
        console.error('\n❌ FATAL ERROR: Database credentials not configured!');
        console.error('   Please ensure DB_USER and DB_PASSWORD environment variables are set.');
        process.exit(1);
    }

    // Database connection pool
    pool = new Pool({
        host: dbHost,
        port: process.env.DB_PORT || 5432,
        database: process.env.DB_NAME || 'shopsphere',
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        max: 20,
        idleTimeoutMillis: 30000,
        connectionTimeoutMillis: 10000,
    });

    console.log(`📊 Connecting to database at ${dbHost}:${process.env.DB_PORT || 5432}...`);
}


// Handle pool errors (only in production mode)
if (pool) {
    pool.on('error', (err, client) => {
        console.error('Unexpected error on idle client', err);
    });

    pool.on('connect', (client) => {
        console.log('New client connected to database');
    });

    pool.on('remove', (client) => {
        console.log('Client removed from pool');
    });

    // Test database connection with retry
    const testConnection = async (retries = 5) => {
        for (let i = 0; i < retries; i++) {
            try {
                const res = await pool.query('SELECT NOW()');
                console.log('✅ Database connected successfully at:', res.rows[0].now);
                return true;
            } catch (err) {
                console.error(`❌ Database connection attempt ${i + 1}/${retries} failed:`, err.message);
                if (i < retries - 1) {
                    console.log(`   Retrying in ${3}  seconds...`);
                    await new Promise(resolve => setTimeout(resolve, 3000));
                }
            }
        }
        console.error('❌ Failed to connect to database after all retries');
        return false;
    };

    // Run connection test
    testConnection();
}



// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

// Gradient mappings for products
const gradients = {
    'Minimal': 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    'Artistic': 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
    'Protection': 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
    'Glitter': 'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)',
    'Eco': 'linear-gradient(135deg, #fa709a 0%, #fee140 100%)',
    'Ocean': 'linear-gradient(135deg, #fa709a 0%, #fee140 100%)',
    'Special': 'linear-gradient(135deg, #30cfd0 0%, #330867 100%)',
    'Natural': 'linear-gradient(135deg, #8E6E53 0%, #D4A574 100%)',
    'Luxury': 'linear-gradient(135deg, #ECECEC 0%, #9E9E9E 100%)',
    'Colorful': 'linear-gradient(135deg, #FFB75E 0%, #ED8F03 100%)',
    'Sport': 'linear-gradient(135deg, #1A1A1A 0%, #4A4A4A 100%)'
};

const productImages = {
    'Minimal': '/images/minimal-case.jpg',
    'Artistic': '/images/artistic-case.jpg',
    'Protection': '/images/protection-case.jpg',
    'Glitter': '/images/glitter-case.jpg',
    'Eco': '/images/ocean-case.jpg',
    'Ocean': '/images/ocean-case.jpg',
    'Special': '/images/night-sky.png',
    'Natural': '/images/wood-grain-natural.png', // Was natural-case.jpg, now specific wood grain
    'Luxury': '/images/marble-elegence.png',
    'Colorful': '/images/sunset-gradiant.png',
    'Sport': '/images/carbon-fiber.png'
};

// API endpoint for products (from database)
app.get('/api/products', async (req, res) => {
    // In dev mode, use mock data
    if (DEV_MODE) {
        return res.json([
            {
                id: 1,
                name: 'Eco Minimal Case',
                category: 'Minimal',
                description: 'Sleek biodegradable design with minimalist aesthetic.',
                price: 24.99,
                badge: 'BESTSELLER',
                gradient: gradients['Minimal'],
                image: '/images/minimal-case.jpg',
                imageType: 'photo'
            },
            {
                id: 2,
                name: 'Artistic Expression',
                category: 'Artistic',
                description: 'Vibrant hand-crafted patterns for creative souls.',
                price: 29.99,
                gradient: gradients['Artistic'],
                image: '/images/artistic-case.jpg',
                imageType: 'photo'
            },
            {
                id: 3,
                name: 'Ultra Protection Pro',
                category: 'Protection',
                description: 'Military-grade protection meets sustainable materials.',
                price: 34.99,
                gradient: gradients['Protection'],
                image: '/images/protection-case.jpg',
                imageType: 'photo'
            },
            {
                id: 4,
                name: 'Glitter Dreams',
                category: 'Glitter',
                description: 'Sparkle sustainably with eco-friendly biodegradable glitter.',
                price: 27.99,
                badge: 'LIMITED',
                gradient: gradients['Glitter'],
                image: '/images/glitter-case.jpg',
                imageType: 'photo'
            },
            {
                id: 5,
                name: 'Ocean Blue',
                category: 'Ocean',
                description: 'Inspired by the deep sea, made from recycled ocean plastic.',
                price: 26.99,
                gradient: gradients['Ocean'],
                image: '/images/ocean-case.jpg',
                imageType: 'photo'
            },
            {
                id: 6,
                name: 'Natural Wood',
                category: 'Natural',
                description: 'Real bamboo texture with protective eco-resin coating.',
                price: 32.99,
                gradient: gradients['Natural'],
                image: productImages['Natural'],
                imageType: 'photo'
            }
        ]);
    }

    try {
        const result = await pool.query(`
            SELECT
                id,
                name,
                category,
                description,
                price,
                material,
                stock
            FROM products
            ORDER BY id
        `);

        const products = result.rows.map(product => ({
            id: product.id,
            name: product.name,
            category: product.category,
            description: product.description,
            price: parseFloat(product.price),
            material: product.material,
            stock: product.stock,
            gradient: gradients[product.category] || gradients['Minimal'],
            image: productImages[product.category] || 'phone_iphone',
            imageType: productImages[product.category] ? 'photo' : 'icon',
            badge: product.stock > 150 ? 'BESTSELLER' : product.stock < 100 ? 'LIMITED' : null
        }));

        res.json(products);
    } catch (error) {
        console.error('Error fetching products:', error);
        res.status(500).json({ error: 'Failed to load products' });
    }
});

// API endpoint for stats (from database)
app.get('/api/stats', async (req, res) => {
    try {
        const customersResult = await pool.query('SELECT COUNT(*) as count FROM customers');
        const ordersResult = await pool.query('SELECT COUNT(*) as count FROM orders WHERE status = \'delivered\'');
        const revenueResult = await pool.query('SELECT SUM(total_amount) as total FROM orders WHERE status = \'delivered\'');

        res.json({
            customers: customersResult.rows[0].count,
            orders: ordersResult.rows[0].count,
            revenue: parseFloat(revenueResult.rows[0].total || 0)
        });
    } catch (error) {
        console.error('Error fetching stats:', error);
        res.json({
            customers: 15000,
            orders: 350000,
            revenue: 4200000
        });
    }
});

// API endpoint for customers
app.get('/api/customers', async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT id, email, first_name, last_name, country, created_at
            FROM customers
            ORDER BY created_at DESC
            LIMIT 20
        `);
        res.json(result.rows);
    } catch (error) {
        console.error('Error fetching customers:', error);
        res.status(500).json({ error: 'Failed to fetch customers' });
    }
});

// API endpoint for orders
app.get('/api/orders', async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT
                o.id,
                o.total_amount,
                o.status,
                o.order_date,
                c.first_name,
                c.last_name,
                c.email
            FROM orders o
            JOIN customers c ON o.customer_id = c.id
            ORDER BY o.order_date DESC
            LIMIT 50
        `);
        res.json(result.rows);
    } catch (error) {
        console.error('Error fetching orders:', error);
        res.status(500).json({ error: 'Failed to fetch orders' });
    }
});

// API endpoint for order items
app.get('/api/order-items', async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT
                oi.id,
                oi.order_id,
                oi.product_id,
                oi.quantity,
                oi.price,
                p.name as product_name,
                p.category
            FROM order_items oi
            JOIN products p ON oi.product_id = p.id
            ORDER BY oi.id DESC
            LIMIT 100
        `);
        res.json(result.rows);
    } catch (error) {
        console.error('Error fetching order items:', error);
        res.status(500).json({ error: 'Failed to fetch order items' });
    }
});

// Health check

app.get('/health', (req, res) => {
    pool.query('SELECT 1', (err) => {
        if (err) {
            res.status(503).json({ status: 'unhealthy', database: 'disconnected', error: err.message });
        } else {
            res.json({ status: 'healthy', database: 'connected' });
        }
    });
});

// Debug endpoint
app.get('/api/debug', async (req, res) => {
    const debugInfo = {
        dbHost: dbHost,
        dbPort: 5432,
        dbUser: 'shopsphere_user',
        dbName: 'shopsphere',
        tests: {}
    };

    // Test 1: Database connection
    try {
        const result = await pool.query('SELECT NOW() as time, version() as version');
        debugInfo.tests.connection = {
            status: 'success',
            time: result.rows[0].time,
            version: result.rows[0].version
        };
    } catch (err) {
        debugInfo.tests.connection = {
            status: 'failed',
            error: err.message,
            code: err.code
        };
    }

    // Test 2: Products count
    try {
        const result = await pool.query('SELECT COUNT(*) as count FROM products');
        debugInfo.tests.products = {
            status: 'success',
            count: parseInt(result.rows[0].count)
        };
    } catch (err) {
        debugInfo.tests.products = {
            status: 'failed',
            error: err.message
        };
    }

    // Test 3: Customers count
    try {
        const result = await pool.query('SELECT COUNT(*) as count FROM customers');
        debugInfo.tests.customers = {
            status: 'success',
            count: parseInt(result.rows[0].count)
        };
    } catch (err) {
        debugInfo.tests.customers = {
            status: 'failed',
            error: err.message
        };
    }

    // Test 4: Network connectivity
    const { exec } = require('child_process');
    exec(`ping -c 1 ${dbHost}`, (error, stdout, stderr) => {
        if (error) {
            debugInfo.tests.ping = { status: 'failed', error: error.message };
        } else {
            debugInfo.tests.ping = { status: 'success', output: stdout.substring(0, 200) };
        }
        res.json(debugInfo);
    });
});

// Catch all route - serve index.html
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
    console.log(`ShopSphere server running on port ${PORT}`);
    console.log(`Database host: ${dbHost}`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
    console.log('SIGTERM signal received: closing HTTP server');
    pool.end(() => {
        console.log('Database pool closed');
        process.exit(0);
    });
});

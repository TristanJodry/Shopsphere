// Tab switching functionality
const tabs = document.querySelectorAll('.tab');
const tabContents = document.querySelectorAll('.tab-content');

tabs.forEach(tab => {
    tab.addEventListener('click', () => {
        const targetTab = tab.dataset.tab;

        // Update active tab
        tabs.forEach(t => t.classList.remove('active'));
        tab.classList.add('active');

        // Update active content
        tabContents.forEach(content => {
            content.classList.remove('active');
        });
        document.getElementById(targetTab).classList.add('active');
    });
});

// Fetch and display customers
async function loadCustomers() {
    try {
        const response = await fetch('/api/customers');
        const customers = await response.json();

        const container = document.getElementById('customers-table');
        const count = document.getElementById('customers-count');

        count.textContent = `${customers.length} records`;

        if (customers.length === 0) {
            container.innerHTML = '<div class="no-data">No customers found</div>';
            return;
        }

        const table = `
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Email</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Country</th>
                        <th>Created At</th>
                    </tr>
                </thead>
                <tbody>
                    ${customers.map(customer => `
                        <tr>
                            <td>${customer.id}</td>
                            <td>${customer.email}</td>
                            <td>${customer.first_name}</td>
                            <td>${customer.last_name}</td>
                            <td>${customer.country}</td>
                            <td>${new Date(customer.created_at).toLocaleDateString()}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;

        container.innerHTML = table;
    } catch (error) {
        console.error('Error loading customers:', error);
        document.getElementById('customers-table').innerHTML =
            '<div class="error">Failed to load customers. Please try again.</div>';
    }
}

// Fetch and display orders
async function loadOrders() {
    try {
        const response = await fetch('/api/orders');
        const orders = await response.json();

        const container = document.getElementById('orders-table');
        const count = document.getElementById('orders-count');

        count.textContent = `${orders.length} records`;

        if (orders.length === 0) {
            container.innerHTML = '<div class="no-data">No orders found</div>';
            return;
        }

        const table = `
            <table>
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Customer</th>
                        <th>Email</th>
                        <th>Total Amount</th>
                        <th>Status</th>
                        <th>Order Date</th>
                    </tr>
                </thead>
                <tbody>
                    ${orders.map(order => `
                        <tr>
                            <td>#${order.id}</td>
                            <td>${order.first_name} ${order.last_name}</td>
                            <td>${order.email}</td>
                            <td>€${parseFloat(order.total_amount).toFixed(2)}</td>
                            <td>
                                <span class="status-badge status-${order.status}">
                                    ${order.status}
                                </span>
                            </td>
                            <td>${new Date(order.order_date).toLocaleDateString()}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;

        container.innerHTML = table;
    } catch (error) {
        console.error('Error loading orders:', error);
        document.getElementById('orders-table').innerHTML =
            '<div class="error">Failed to load orders. Please try again.</div>';
    }
}

// Fetch and display order items
async function loadOrderItems() {
    try {
        const response = await fetch('/api/order-items');

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const items = await response.json();

        const container = document.getElementById('order-items-table');
        const count = document.getElementById('order-items-count');

        count.textContent = `${items.length} records`;

        if (items.length === 0) {
            container.innerHTML = '<div class="no-data">No order items found</div>';
            return;
        }

        const table = `
            <table>
                <thead>
                    <tr>
                        <th>Item ID</th>
                        <th>Order ID</th>
                        <th>Product ID</th>
                        <th>Product Name</th>
                        <th>Category</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    ${items.map(item => `
                        <tr>
                            <td>${item.id}</td>
                            <td>#${item.order_id}</td>
                            <td>${item.product_id}</td>
                            <td>${item.product_name}</td>
                            <td>${item.category}</td>
                            <td>${item.quantity}</td>
                            <td>€${parseFloat(item.price).toFixed(2)}</td>
                            <td>€${(parseFloat(item.price) * item.quantity).toFixed(2)}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;

        container.innerHTML = table;
    } catch (error) {
        console.error('Error loading order items:', error);
        document.getElementById('order-items-table').innerHTML =
            '<div class="error">Failed to load order items. Please try again.</div>';
    }
}

// Load all data on page load
document.addEventListener('DOMContentLoaded', () => {
    loadCustomers();
    loadOrders();
    loadOrderItems();
});
